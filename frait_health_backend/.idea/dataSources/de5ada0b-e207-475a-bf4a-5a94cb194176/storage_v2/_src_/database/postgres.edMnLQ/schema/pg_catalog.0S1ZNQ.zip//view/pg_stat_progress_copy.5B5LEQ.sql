create view pg_stat_progress_copy
            (pid, datid, datname, relid, command, type, bytes_processed, bytes_total, tuples_processed,
             tuples_excluded) as
SELECT s.pid,
       s.datid,
       d.datname,
       s.relid,
       CASE s.param5
           WHEN 1 THEN 'COPY FROM'::text
           WHEN 2 THEN 'COPY TO'::text
           ELSE NULL::text
           END  AS command,
       CASE s.param6
           WHEN 1 THEN 'FILE'::text
           WHEN 2 THEN 'PROGRAM'::text
           WHEN 3 THEN 'PIPE'::text
           WHEN 4 THEN 'CALLBACK'::text
           ELSE NULL::text
           END  AS type,
       s.param1 AS bytes_processed,
       s.param2 AS bytes_total,
       s.param3 AS tuples_processed,
       s.param4 AS tuples_excluded
FROM pg_stat_get_progress_info('COPY'::text) s(pid, datid, relid, param1, param2, param3, param4, param5, param6,
                                               param7, param8, param9, param10, param11, param12, param13, param14,
                                               param15, param16, param17, param18, param19, param20)
         LEFT JOIN pg_database d ON s.datid = d.oid;

alter table pg_stat_progress_copy
    owner to frait_health_backend;

grant select on pg_stat_progress_copy to public;

