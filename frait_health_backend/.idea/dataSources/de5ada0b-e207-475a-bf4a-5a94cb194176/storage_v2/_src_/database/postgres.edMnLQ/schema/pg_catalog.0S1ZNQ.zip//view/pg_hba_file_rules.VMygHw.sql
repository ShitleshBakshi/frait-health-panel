create view pg_hba_file_rules
            (rule_number, file_name, line_number, type, database, user_name, address, netmask, auth_method, options,
             error) as
SELECT rule_number,
       file_name,
       line_number,
       type,
       database,
       user_name,
       address,
       netmask,
       auth_method,
       options,
       error
FROM pg_hba_file_rules() a(rule_number, file_name, line_number, type, database, user_name, address, netmask,
                           auth_method, options, error);

alter table pg_hba_file_rules
    owner to frait_health_backend;

